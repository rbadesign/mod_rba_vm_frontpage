<?php
/*********** XML PARAMETERS AND VALUES ************/
$xml_item = "module";// component | template
$xml_file = "mod_rba_vm_frontpage.xml";		
$xml_name = "Rba VirtueMart Frontpage";
$xml_creation_date = "29/03/2013";
$xml_author = "RBA DESIGN INTERNATIONAL LLC";
$xml_author_email = "info@rbadesign.us";
$xml_author_url = "rbadesign.us";
$xml_copyright = "RBA DESIGN INTERNATIONAL LLC";
$xml_license = "Commercial";
$xml_version = "1.0";
$xml_description = "VirtueMart Frontpage displays categories and products in columns";
$xml_copy_file = 1;//Copy other files in to administration area (only for development), ./front, ./language, ./other

$xml_menu = array();
$xml_submenu = array();

$xml_install_file = ''; 
$xml_uninstall_file = '';
/*********** XML PARAMETERS AND VALUES ************/
?>